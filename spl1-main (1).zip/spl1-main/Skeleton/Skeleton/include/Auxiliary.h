#pragma once
#include <iostream>
#include <vector>
#include <sstream>
#include <string>
#include <Simulation.h>

class Auxiliary{
    public:
        static std::vector<std::string> parseArguments(const std::string& line);
         
};
